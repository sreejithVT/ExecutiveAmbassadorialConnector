-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 10, 2022 at 01:49 PM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `executiveacdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `number` int(15) NOT NULL,
  `uploaderid` varchar(100) DEFAULT NULL,
  `uploadername` varchar(100) DEFAULT NULL,
  `blogname` varchar(25) DEFAULT NULL,
  `blogdetails` varchar(2000) DEFAULT NULL,
  `blogdate` varchar(15) DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'created'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`number`, `uploaderid`, `uploadername`, `blogname`, `blogdetails`, `blogdate`, `status`) VALUES
(1, '1', 'test', 'blog1', 'blog1details', '2022-10-01', 'deleted'),
(2, '2', 'test2', 'blog2', 'blog2details', '2022-10-01', 'active'),
(3, '4', 'st3', 'blog3', 'blog3details', '2022-10-01', 'created');

-- --------------------------------------------------------

--
-- Table structure for table `bloodrequirements`
--

CREATE TABLE `bloodrequirements` (
  `number` int(15) NOT NULL,
  `postedid` varchar(100) DEFAULT NULL,
  `postedname` varchar(100) DEFAULT NULL,
  `bloodgroup` varchar(25) DEFAULT NULL,
  `details` varchar(2000) DEFAULT NULL,
  `postdate` varchar(15) DEFAULT NULL,
  `status` varchar(50) DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `bloodrequirements`
--

INSERT INTO `bloodrequirements` (`number`, `postedid`, `postedname`, `bloodgroup`, `details`, `postdate`, `status`) VALUES
(2, 'Admin', 'Admin', 'O+', 'fsdfdsafdsf', '2022-10-01', 'active'),
(3, '2', 'fdsfds', 'dbstd1', 'dbstd1details', '2022-10-01', 'deleted');

-- --------------------------------------------------------

--
-- Table structure for table `bloodresponse`
--

CREATE TABLE `bloodresponse` (
  `number` int(15) NOT NULL,
  `bloodrequirementid` varchar(100) DEFAULT NULL,
  `postedid` varchar(100) DEFAULT NULL,
  `postedname` varchar(100) DEFAULT NULL,
  `bloodgroup` varchar(25) DEFAULT NULL,
  `details` varchar(2000) DEFAULT NULL,
  `postdate` varchar(15) DEFAULT NULL,
  `responderid` varchar(100) DEFAULT NULL,
  `respondername` varchar(100) DEFAULT NULL,
  `responderdetails` varchar(100) DEFAULT NULL,
  `respondeddate` varchar(100) DEFAULT NULL,
  `status` varchar(50) DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `bloodresponse`
--

INSERT INTO `bloodresponse` (`number`, `bloodrequirementid`, `postedid`, `postedname`, `bloodgroup`, `details`, `postdate`, `responderid`, `respondername`, `responderdetails`, `respondeddate`, `status`) VALUES
(1, '2', 'Admin', 'Admin', 'O+', 'fsdfdsafdsf', '2022-10-01', '2', 'fdsfds', 'testbdrespose', '2022-10-01', 'active'),
(2, '2', 'Admin', 'Admin', 'O+', 'fsdfdsafdsf', '2022-10-01', '2', 'fdsfds', 'respond2', '2022-10-01', 'deleted');

-- --------------------------------------------------------

--
-- Table structure for table `eventresponse`
--

CREATE TABLE `eventresponse` (
  `number` int(15) NOT NULL,
  `eventid` varchar(100) DEFAULT NULL,
  `event` varchar(25) DEFAULT NULL,
  `details` varchar(2000) DEFAULT NULL,
  `postdate` varchar(15) DEFAULT NULL,
  `responderid` varchar(100) DEFAULT NULL,
  `respondername` varchar(100) DEFAULT NULL,
  `responderdetails` varchar(100) DEFAULT NULL,
  `respondeddate` varchar(100) DEFAULT NULL,
  `status` varchar(50) DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `eventresponse`
--

INSERT INTO `eventresponse` (`number`, `eventid`, `event`, `details`, `postdate`, `responderid`, `respondername`, `responderdetails`, `respondeddate`, `status`) VALUES
(1, '2', 'event2', 'event2Details', '2022-10-01', '2', 'fdsfds', 'asdff', '2022-10-01', 'active'),
(5, '2', 'event2', 'event2Details', '2022-10-01', '2', 'fdsfds', 'respond2', '2022-10-01', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `number` int(15) NOT NULL,
  `eventname` varchar(25) DEFAULT NULL,
  `eventdetails` varchar(2000) DEFAULT NULL,
  `date` varchar(15) DEFAULT NULL,
  `status` varchar(50) DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`number`, `eventname`, `eventdetails`, `date`, `status`) VALUES
(1, 'event1', 'event1Details', '2022-10-01', 'deleted'),
(2, 'event2', 'event2Details', '2022-10-01', 'active'),
(3, 'event3', 'event3Details', '2022-10-01', 'deleted');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `number` int(15) NOT NULL,
  `uploaderid` varchar(100) DEFAULT NULL,
  `uploadername` varchar(100) DEFAULT NULL,
  `fbname` varchar(25) DEFAULT NULL,
  `fbdetails` varchar(2000) DEFAULT NULL,
  `posteddate` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`number`, `uploaderid`, `uploadername`, `fbname`, `fbdetails`, `posteddate`) VALUES
(1, '1', 'test', 'fb1', 'fb1Details', '2022-10-01'),
(2, '4', 'test2', 'fb2', 'fb2Details', '2022-10-01'),
(3, '4', 'st3', 'fb5', 'fb5details', '2022-10-01'),
(4, '2', 'tf1', 'sdfsdf', 'adfvdsfvgfdgergfdgdscvscdasdsdfc', '2022-10-01');

-- --------------------------------------------------------

--
-- Table structure for table `fundrequirements`
--

CREATE TABLE `fundrequirements` (
  `number` int(15) NOT NULL,
  `postedid` varchar(100) DEFAULT NULL,
  `postedname` varchar(100) DEFAULT NULL,
  `fundevent` varchar(25) DEFAULT NULL,
  `details` varchar(2000) DEFAULT NULL,
  `postdate` varchar(15) DEFAULT NULL,
  `status` varchar(50) DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `fundrequirements`
--

INSERT INTO `fundrequirements` (`number`, `postedid`, `postedname`, `fundevent`, `details`, `postdate`, `status`) VALUES
(1, 'admin', 'admin', 'fe1', 'fe1details', '2022-10-01', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `fundresponse`
--

CREATE TABLE `fundresponse` (
  `number` int(15) NOT NULL,
  `fundrequirementid` varchar(100) DEFAULT NULL,
  `postedid` varchar(100) DEFAULT NULL,
  `postedname` varchar(100) DEFAULT NULL,
  `fundevent` varchar(25) DEFAULT NULL,
  `details` varchar(2000) DEFAULT NULL,
  `postdate` varchar(15) DEFAULT NULL,
  `responderid` varchar(100) DEFAULT NULL,
  `respondername` varchar(100) DEFAULT NULL,
  `responderdetails` varchar(100) DEFAULT NULL,
  `paidamount` varchar(100) DEFAULT NULL,
  `paymentdate` varchar(50) DEFAULT NULL,
  `status` varchar(100) DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `fundresponse`
--

INSERT INTO `fundresponse` (`number`, `fundrequirementid`, `postedid`, `postedname`, `fundevent`, `details`, `postdate`, `responderid`, `respondername`, `responderdetails`, `paidamount`, `paymentdate`, `status`) VALUES
(1, '1', 'admin', 'admin', 'fe1', 'fe1details', '2022-10-01', '2', 'fdsfds', NULL, '100', '2022-10-01', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `jobrequirements`
--

CREATE TABLE `jobrequirements` (
  `number` int(15) NOT NULL,
  `postedid` varchar(50) DEFAULT NULL,
  `postedname` varchar(100) DEFAULT NULL,
  `jobname` varchar(25) DEFAULT NULL,
  `jobdetails` varchar(2000) DEFAULT NULL,
  `postdate` varchar(15) DEFAULT NULL,
  `status` varchar(50) DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jobrequirements`
--

INSERT INTO `jobrequirements` (`number`, `postedid`, `postedname`, `jobname`, `jobdetails`, `postdate`, `status`) VALUES
(1, 'admin', 'admin', 'jkkjk', 'mknbjvbjnvbn', '2022-10-01', 'active'),
(3, 'admin', 'admin', 'jj', 'jj', '2022-10-01', 'active'),
(4, '2', 'fdsfds', 'std1jbreq1', 'std1jbreq1details', '2022-10-01', 'deleted');

-- --------------------------------------------------------

--
-- Table structure for table `jobresponse`
--

CREATE TABLE `jobresponse` (
  `number` int(15) NOT NULL,
  `jobrequirementid` varchar(100) DEFAULT NULL,
  `postedid` varchar(100) DEFAULT NULL,
  `postedname` varchar(100) DEFAULT NULL,
  `jobname` varchar(25) DEFAULT NULL,
  `details` varchar(2000) DEFAULT NULL,
  `postdate` varchar(15) DEFAULT NULL,
  `responderid` varchar(100) DEFAULT NULL,
  `respondername` varchar(100) DEFAULT NULL,
  `responderdetails` varchar(100) DEFAULT NULL,
  `respondeddate` varchar(100) DEFAULT NULL,
  `status` varchar(50) DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jobresponse`
--

INSERT INTO `jobresponse` (`number`, `jobrequirementid`, `postedid`, `postedname`, `jobname`, `details`, `postdate`, `responderid`, `respondername`, `responderdetails`, `respondeddate`, `status`) VALUES
(1, '3', 'admin', 'admin', 'jj', 'jj', '2022-10-01', '2', 'fdsfds', 'hgfgfg', '2022-10-01', 'deleted'),
(2, '3', 'admin', 'admin', 'jj', 'jj', '2022-10-01', '2', 'fdsfds', 'job respond2', '2022-10-01', 'deleted');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `number` int(15) NOT NULL,
  `registrationno` varchar(100) NOT NULL,
  `firstname` varchar(25) DEFAULT NULL,
  `lastname` varchar(25) DEFAULT NULL,
  `dob` varchar(15) DEFAULT NULL,
  `mobilenum` varchar(25) DEFAULT NULL,
  `emailid` varchar(25) DEFAULT NULL,
  `regdate` varchar(50) DEFAULT NULL,
  `collegename` varchar(50) DEFAULT NULL,
  `userid` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `course` varchar(100) DEFAULT NULL,
  `year` varchar(20) DEFAULT NULL,
  `status` varchar(50) DEFAULT 'created',
  `imagename` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`number`, `registrationno`, `firstname`, `lastname`, `dob`, `mobilenum`, `emailid`, `regdate`, `collegename`, `userid`, `password`, `course`, `year`, `status`, `imagename`) VALUES
(2, '111111', 'fdsfds', 'dfdsfdf', '1989-02-12', '1234567890', 's@s.com', '10/02/2020', 'c1', 'stud1', 'stud1', 'cr1', '2006', 'active', '111111.jpg'),
(3, '222222', 'studtwofirst', 'studtwolast', '1989-01-01', '1234567893', 'stud2@test.com', '11/02/2020', 'c1', 'stud2', 'stud2', 'cr1', '2006', 'active', '222222.jpg'),
(4, '33333', 'studthree', 'studthree', '1989-02-05', '1234567897', 'sud3@stud3.com', '11/02/2020', 'c1', 'stud3', 'stud3', 'cr1', '2006', 'deleted', '33333.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `videochat`
--

CREATE TABLE `videochat` (
  `id` int(35) NOT NULL,
  `toid` varchar(35) DEFAULT NULL,
  `fromid` varchar(35) DEFAULT NULL,
  `fromname` varchar(50) DEFAULT NULL,
  `link` varchar(55) DEFAULT NULL,
  `senddate` varchar(35) DEFAULT NULL,
  `status` varchar(35) DEFAULT NULL,
  `chatdate` varchar(35) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `videochat`
--

INSERT INTO `videochat` (`id`, `toid`, `fromid`, `fromname`, `link`, `senddate`, `status`, `chatdate`) VALUES
(1, '3', '2', NULL, 'https://meet.jit.si/9987', '2022-10-01', 'closed', '2022-10-01'),
(3, '3', '2', NULL, 'https://meet.jit.si/8625', '2022-10-01', 'closed', '2022-10-01'),
(4, '3', '2', 'fdsfds', 'https://meet.jit.si/7674', '2022-10-01', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`number`);

--
-- Indexes for table `bloodrequirements`
--
ALTER TABLE `bloodrequirements`
  ADD PRIMARY KEY (`number`);

--
-- Indexes for table `bloodresponse`
--
ALTER TABLE `bloodresponse`
  ADD PRIMARY KEY (`number`);

--
-- Indexes for table `eventresponse`
--
ALTER TABLE `eventresponse`
  ADD PRIMARY KEY (`number`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`number`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`number`);

--
-- Indexes for table `fundrequirements`
--
ALTER TABLE `fundrequirements`
  ADD PRIMARY KEY (`number`);

--
-- Indexes for table `fundresponse`
--
ALTER TABLE `fundresponse`
  ADD PRIMARY KEY (`number`);

--
-- Indexes for table `jobrequirements`
--
ALTER TABLE `jobrequirements`
  ADD PRIMARY KEY (`number`);

--
-- Indexes for table `jobresponse`
--
ALTER TABLE `jobresponse`
  ADD PRIMARY KEY (`number`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`number`,`registrationno`);

--
-- Indexes for table `videochat`
--
ALTER TABLE `videochat`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `number` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `bloodrequirements`
--
ALTER TABLE `bloodrequirements`
  MODIFY `number` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `bloodresponse`
--
ALTER TABLE `bloodresponse`
  MODIFY `number` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `eventresponse`
--
ALTER TABLE `eventresponse`
  MODIFY `number` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `number` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `number` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `fundrequirements`
--
ALTER TABLE `fundrequirements`
  MODIFY `number` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `fundresponse`
--
ALTER TABLE `fundresponse`
  MODIFY `number` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `jobrequirements`
--
ALTER TABLE `jobrequirements`
  MODIFY `number` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `jobresponse`
--
ALTER TABLE `jobresponse`
  MODIFY `number` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `number` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `videochat`
--
ALTER TABLE `videochat`
  MODIFY `id` int(35) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
