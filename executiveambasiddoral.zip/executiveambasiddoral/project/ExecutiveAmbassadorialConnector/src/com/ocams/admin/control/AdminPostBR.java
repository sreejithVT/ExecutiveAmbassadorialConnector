package com.ocams.admin.control;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ocams.admin.dao.OCAMSDAO;


/**
 * Servlet implementation class Login
 */
public class AdminPostBR extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String error = null;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AdminPostBR() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// Get the user details from login
		/**
		 * @see HttpServlet#doPost(HttpServletRequest request,
		 *      HttpServletResponse response)
		 */
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		System.out.println("capostfeedback");

		
	String bloodgroup = request.getParameter("bloodgroup");
	String bddetails = request.getParameter("bddetails");
			
		System.out.println(bloodgroup);
		System.out.println(bddetails);
		
		boolean post = OCAMSDAO.postBR(bloodgroup,bddetails);
		System.out.println(post);
		if(post)
		{
			request.setAttribute("returnMsg", "Succesfully Posted");
		
			request.getRequestDispatcher("adminviewbd.jsp").forward(request,
					response);
		}
	else
	{
			request.setAttribute("returnMsg", "Something went wrong..Try after sometime.");
			request.getRequestDispatcher("adminpostbd.jsp").forward(request,
					response);
		}

	}

	
	}




		
		
		