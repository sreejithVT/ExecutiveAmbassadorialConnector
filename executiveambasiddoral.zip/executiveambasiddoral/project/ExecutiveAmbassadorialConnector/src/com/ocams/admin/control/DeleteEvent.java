package com.ocams.admin.control;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ocams.admin.dao.OCAMSDAO;

/**
 * Servlet implementation class Login
 */
public class DeleteEvent extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String error = null;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public DeleteEvent() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// Get the user details from login
		/**
		 * @see HttpServlet#doPost(HttpServletRequest request,
		 *      HttpServletResponse response)
		 */
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// To get member details from jsp
		System.out.println("This is from delete Event");
		String a = request.getParameter("eventid");
		System.out.println("eventid id from jsp=" + a);

		int rs = OCAMSDAO.deleteEvent(a);
		if (rs == 1) {
			request.getRequestDispatcher("adminviewevents.jsp").forward(request,
					response);
		} else {
			request.setAttribute("Msg", "Unable to Delete");
			request.getRequestDispatcher("adminviewevents.jsp").forward(request,
					response);
		}

	}
}
