package com.ocams.admin.control;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ocams.admin.dao.OCAMSDAO;
import com.ocams.admin.util.AdminUtil;

/**
 * Servlet implementation class Login
 */
public class StudentChangePassword extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String error = null;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public StudentChangePassword() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// Get the user details from login
		/**
		 * @see HttpServlet#doPost(HttpServletRequest request,
		 *      HttpServletResponse response)
		 */
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("studentchangepw");

		// Fuction call to AdminUtil to set change password details

		ArrayList change = AdminUtil.changePasswordDetails(request, response);

		System.out.println(change.get(0));
		System.out.println(change.get(1));
		System.out.println(change.get(2));
		int value = OCAMSDAO.changePasswordStudent(change);
		System.out.println(value);

		if (value != 0) {
			request.setAttribute("returnMsg", "Succesfully Updated");

			request.getRequestDispatcher("studentchangepassword.jsp").forward(
					request, response);
		} else {
			request.setAttribute("returnMsg",
					"Something went wrong..Try after sometime.");
			request.getRequestDispatcher("studentchangepassword.jsp").forward(
					request, response);
		}

	}

}
