package com.ocams.admin.control;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ocams.admin.dao.OCAMSDAO;
import com.ocams.admin.model.Student;
import com.ocams.admin.util.AdminUtil;



/**
 * Servlet implementation class Login
 */
public class StudentJobResponds extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String error = null;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public StudentJobResponds() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// Get the user details from login
		/**
		 * @see HttpServlet#doPost(HttpServletRequest request,
		 *      HttpServletResponse response)
		 */
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("StudentJobResponds");

		String jobrequirementid= request.getParameter("jobrequirementid");
		String postedid= request.getParameter("postedid");
		String postedname= request.getParameter("postedname");
		String jobname= request.getParameter("jobname");
		String details= request.getParameter("details");
		String postdate= request.getParameter("postdate");
		
		
		String responderid= request.getParameter("responderid");
		String respondername= request.getParameter("respondername");
		String responderdetails= request.getParameter("responderdetails");
		
		boolean status=true;
		if(status){
			boolean status1=OCAMSDAO.respondJobRequest(jobrequirementid, postedid, postedname, jobname, details, postdate, responderid, respondername, responderdetails);
			if(status1){
				request.setAttribute("Msg","Successfully Updated.");
			}
			else{
				request.setAttribute("Msg","Something went wrong.Please try after sometime.");
			}
		}
		else{
			request.setAttribute("Msg","Existing records are not matching.");
		}
		
		request.getRequestDispatcher("studentviewothersjobpost.jsp").forward(request,response);
		}
	}


