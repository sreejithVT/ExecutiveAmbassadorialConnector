package com.ocams.admin.control;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ocams.admin.dao.OCAMSDAO;
import com.ocams.admin.model.Admin;
import com.ocams.admin.model.Student;
import com.ocams.admin.util.AdminUtil;

/**
 * Servlet implementation class Login
 */
public class StudentLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String error = null;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public StudentLogin() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// Get the user details from login
		/**
		 * @see HttpServlet#doPost(HttpServletRequest request,
		 *      HttpServletResponse response)
		 */
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// To get member  credentials
		System.out.println("student");
       
		
		String uname = request.getParameter("username");
		String pass = request.getParameter("password");
		Admin login = new Admin();
		login.setUserName(uname);
		login.setPassWord(pass);
		//Sending message to the user
		Admin status1 = OCAMSDAO.loginAdmin(uname);
		if (AdminUtil.compareAdminValue(login, status1)) {
			request.getSession().setAttribute("usernameS", status1.getUserName());
			request.getSession().setAttribute("useridS", status1.getNumber());
			request.setAttribute("Msg", "Successfully Updated.");
			request.getRequestDispatcher("serverhome.jsp").forward(request,
					response);

		} else{
		
		
		String userid=request.getParameter("username");
		String password=request.getParameter("password");
		Student login1=new Student();
		//login1.setAadharid(aaid);
		login1.setUserid(userid);
		login1.setPassword(password);
		//Admin login = AdminUtil.populateadminDetailsFromJsp(request, response);
		
		Student status=OCAMSDAO.loginStudent(login1);
		if(AdminUtil.compareStudentValue(login1, status)){
			
				System.out.println("status.getNumber()====="+status.getNumber());
			request.getSession().setAttribute("mnumber",status.getNumber());	
				request.getSession().setAttribute("suname",status.getFirstName());
				request.getSession().setAttribute("userid",status.getUserid());
				request.getSession().setAttribute("semail",status.getEmailId());
				request.getSession().setAttribute("collegename",status.getCollegename());
				request.getRequestDispatcher("studenthome.jsp").forward(request,response);
				
			

		}
		else{
			request.setAttribute("Msg","Userid or password is not matching.");
		
		request.getRequestDispatcher("studentlogin.jsp").forward(request,response);
		}}
	}
	}


