package com.ocams.admin.control;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ocams.admin.dao.OCAMSDAO;


/**
 * Servlet implementation class Login
 */
public class StudentPostBlog extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String error = null;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public StudentPostBlog() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// Get the user details from login
		/**
		 * @see HttpServlet#doPost(HttpServletRequest request,
		 *      HttpServletResponse response)
		 */
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		System.out.println("capostfeedback");

		
	String blogname = request.getParameter("blogname");
	String blogdetails = request.getParameter("blogdetails");
	String uploaderid="";
	String uploaderName="";
	if(request.getSession().getAttribute("mnumber")!=null){
		uploaderid = request.getSession().getAttribute("mnumber").toString();
	}
	if(request.getSession().getAttribute("suname")!=null){
		uploaderName = request.getSession().getAttribute("suname").toString();
	}
		System.out.println(blogname);
		System.out.println(blogdetails);
		
		boolean post = OCAMSDAO.postBlog(uploaderid,uploaderName,blogname,blogdetails);
		System.out.println(post);
		if(post)
		{
			request.setAttribute("returnMsg", "Succesfully Posted");
		
			request.getRequestDispatcher("studentviewblog.jsp").forward(request,
					response);
		}
	else
	{
			request.setAttribute("returnMsg", "Something went wrong..Try after sometime.");
			request.getRequestDispatcher("studentcreateblog.jsp").forward(request,
					response);
		}

	}

	
	}




		
		
		