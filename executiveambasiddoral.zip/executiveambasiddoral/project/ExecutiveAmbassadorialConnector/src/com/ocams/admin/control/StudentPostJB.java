package com.ocams.admin.control;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ocams.admin.dao.OCAMSDAO;


/**
 * Servlet implementation class Login
 */
public class StudentPostJB extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String error = null;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public StudentPostJB() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// Get the user details from login
		/**
		 * @see HttpServlet#doPost(HttpServletRequest request,
		 *      HttpServletResponse response)
		 */
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		System.out.println("StudentPostJB");

		
	String jobname = request.getParameter("jobname");
	String jbdetails = request.getParameter("jbdetails");
			
		System.out.println(jobname);
		System.out.println(jbdetails);
	    String studentId=request.getSession().getAttribute("mnumber").toString();
	    String studentName=request.getSession().getAttribute("suname").toString();
		boolean post = OCAMSDAO.studentPostJB(jobname,jbdetails,studentId,studentName);
		System.out.println(post);
		if(post)
		{
			request.setAttribute("returnMsg", "Succesfully Posted");
		
			request.getRequestDispatcher("studentpostjob.jsp").forward(request,
					response);
		}
	else
	{
			request.setAttribute("returnMsg", "Something went wrong..Try after sometime.");
			request.getRequestDispatcher("studentpostjob.jsp").forward(request,
					response);
		}

	}

	
	}




		
		
		