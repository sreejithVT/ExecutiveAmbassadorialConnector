package com.ocams.admin.control;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ocams.admin.dao.OCAMSDAO;
import com.ocams.admin.model.Student;
import com.ocams.admin.util.AdminUtil;



/**
 * Servlet implementation class Login
 */
public class StudentRegister extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String error = null;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public StudentRegister() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// Get the user details from login
		/**
		 * @see HttpServlet#doPost(HttpServletRequest request,
		 *      HttpServletResponse response)
		 */
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("studentregister");

		Student detail = AdminUtil.populateStudentDetailsFromJsp(request, response);
		System.out.println(detail.getFirstName());
		System.out.println(detail);
		detail.toString();
		boolean status=OCAMSDAO.checkExisitingRegistration(detail);
		if(status){
			boolean status1=OCAMSDAO.registrationStudent(detail);
			if(status1){
				request.setAttribute("Msg","Successfully Updated.");
			}
			else{
				request.setAttribute("Msg","Something went wrong.Please try after sometime.");
			}
		}
		else{
			request.setAttribute("Msg","Existing records are not matching.");
		}
		
		request.getRequestDispatcher("studentregister.jsp").forward(request,response);
		}
	}


