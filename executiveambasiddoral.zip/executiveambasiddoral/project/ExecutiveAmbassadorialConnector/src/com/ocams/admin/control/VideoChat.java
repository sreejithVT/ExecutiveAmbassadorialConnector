package com.ocams.admin.control;

import java.io.IOException;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ocams.admin.dao.OCAMSDAO;


/**
 * Servlet implementation class VideoChat
 */
@WebServlet("/VideoChat")
public class VideoChat extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public VideoChat() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("videochat");
	   String fromid=request.getParameter("fromid");
	   System.out.println(fromid);
	   String toid=request.getParameter("toid");
	   
	   System.out.println(toid);
 String fromname=request.getParameter("fromname");
	   
	   System.out.println(fromname);
	   
			 Random rand=new Random();
			   String keycode=String.valueOf(rand.nextInt(10000));
				System.out.println(keycode);
				String link="https://meet.jit.si/"+keycode;

		int rs=OCAMSDAO.videoChat(fromid,fromname,toid,link);
		if(rs!=0)
		{
			request.setAttribute("Msg","you can proceed chat ");
		request.setAttribute("Link",link);
			request.getRequestDispatcher("studentvcrequest.jsp").forward(request,response);
		}
		else
		{
			request.setAttribute("Msg","Unable to send");
			request.getRequestDispatcher("studentvcrequest.jsp").forward(request,response);
		}
}

	}

