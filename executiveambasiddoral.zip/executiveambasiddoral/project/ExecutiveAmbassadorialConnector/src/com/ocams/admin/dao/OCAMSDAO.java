package com.ocams.admin.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import com.ocams.admin.model.Admin;
import com.ocams.admin.model.Student;

public class OCAMSDAO {

	public static Admin loginAdmin(String details) {

		Connection con = null;
		ResultSet rs1 = null;
		System.out.println(details);
		Admin loginDetail = new Admin();
		loginDetail.setUserName("Admin");
		loginDetail.setPassWord("Admin");;
		return loginDetail;
	}
	public static int changePasswordStudent(ArrayList changepass) {
		Connection con = null;
		// PreparedStatement ps = null;
		ResultSet rs2 = null;
		// boolean status = false;
		String name = changepass.get(0).toString();
		String pass = changepass.get(1).toString();
		String npass = changepass.get(2).toString();
		int value = 0;

		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/executiveacdb", "root", "");
			Statement ps2 = con.createStatement();

			value = ps2
					.executeUpdate("update Registration set password='"
							+ npass + "' where userid='" + name
							+ "' and password='" + pass + "'");

			con.close();
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return value;
	}	
	public static Student loginStudent(Student u) {

		Connection con = null;
		ResultSet rs1 = null;
		System.out.println(u.getUserid());
		System.out.println(u.getPassword());
		Student loginDetail = new Student();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/executiveacdb", "root", "");
			Statement ps = con.createStatement();
			String q="select * from Registration where userid='"+ u.getUserid() + "' and password='"+u.getPassword()+"' and status='active'";
System.out.println("qqqqqqqq="+q);
			rs1 = ps.executeQuery(q);

			while (rs1.next()) {
				loginDetail.setNumber(rs1.getInt("number"));
				loginDetail.setFirstName(rs1.getString("firstname"));
				loginDetail.setCollegename(rs1.getString("collegename"));
				//loginDetail.setFingerFile(rs1.getString("fingername"));
				loginDetail.setUserid(rs1.getString("userid"));
				loginDetail.setPassword(rs1.getString("password"));
			}

			con.close();
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return loginDetail;
	}
	
	
	public static boolean checkExisitingRegistration(Student u) {
		boolean status=false;
		Connection con = null;
		ResultSet rs1 = null;
		System.out.println(u.getUserid());
		System.out.println(u.getPassword());
		Student loginDetail = new Student();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/executiveacdb", "root", "");
			Statement ps = con.createStatement();
			String q="select * from existingregister where firstname='"+ u.getFirstName() + "' and lastname='"+u.getLastName()+"' and dob='"+u.getDob()+"' and registrationno='"+u.getRegisterno()+"' and collegename='"+u.getCollegename()+"' and course='"+u.getCourse()+"' and year='"+u.getCyear()+"'";
System.out.println("qqqqqqqq="+q);
			rs1 = ps.executeQuery(q);

			while (rs1.next()) {
				status = true;
				}

			con.close();
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return status;
	}
	
	
	public static boolean registrationStudent(Student ad) {
		Connection con = null;
		boolean status = false;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/executiveacdb", "root", "");
			Statement ps = con.createStatement();
			Date date = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yy");
		    sdf = new SimpleDateFormat("dd/MM/yyyy");
		    String  strDate = sdf.format(date);
		    System.out.println("formatted date in dd/MM/yyyy : " + strDate);


			ps.executeUpdate("insert into Registration(firstname,lastname,dob,mobilenum,emailid,collegename,course,year,userid,password,regdate) values('"
					+ ad.getFirstName()
					+ "','"
					+ ad.getLastName()
					+ "','"
					+ ad.getDob()
					+ "','"
					+ ad.getMobNumber()
					+ "','"
					+ ad.getEmailId()
					+ "','"
					+ ad.getCollegename()
					+ "','"
					+ ad.getCourse()
					+ "','"
					+ ad.getCyear()
					+ "','"
					+ ad.getUserid()
					+ "','"
					+ ad.getPassword() + "','"+strDate+"')");
			status = true;
			con.close();
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return status;

	}
	
	public static boolean respondEvent(String eventid,String event,String details,String postdate,String responderid,String respondername,String responderdetails) {
		Connection con = null;
		boolean status = false;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/executiveacdb", "root", "");
			Statement ps = con.createStatement();
			Date date = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yy");
		    sdf = new SimpleDateFormat("dd/MM/yyyy");
		    String  strDate = sdf.format(date);
		    System.out.println("formatted date in dd/MM/yyyy : " + strDate);


			ps.executeUpdate("insert into eventresponse(eventid,event,details,postdate,responderid,respondername,responderdetails,respondeddate) values('"
					+ eventid
					+ "','"
					+ event
					+ "','"
					+ details
					+ "','"
					+ postdate
					+ "','"
					+ responderid
					+ "','"
					+ respondername
					+ "','"
					+ responderdetails
					+ "','"
					+strDate+"')");
			status = true;
			con.close();
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return status;

	}
	
	public static boolean respondFundEvent(String fundrequirementid,String postedid,String postedname,String fundevent,String details,String postdate,String responderid,String respondername,String paidamount) {
		Connection con = null;
		boolean status = false;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/executiveacdb", "root", "");
			Statement ps = con.createStatement();
			Date date = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yy");
		    sdf = new SimpleDateFormat("dd/MM/yyyy");
		    String  strDate = sdf.format(date);
		    System.out.println("formatted date in dd/MM/yyyy : " + strDate);


			ps.executeUpdate("insert into fundresponse(fundrequirementid,postedid,postedname,fundevent,details,postdate,responderid,respondername,paidamount,paymentdate) values('"
					+ fundrequirementid
					+ "','"
					+ postedid
					+ "','"
					+ postedname
					+ "','"
					+ fundevent
					+ "','"
					+ details
					+ "','"
					+ postdate
					+ "','"
					+ responderid
					+ "','"
					+ respondername
					+ "','"
					+ paidamount
					+ "','"
					+strDate+"')");
			status = true;
			con.close();
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return status;

	}
	
	public static boolean respondJobRequest(String jobrequirementid,String postedid,String postedname,String jobname,String details,String postdate,String responderid,String respondername,String responderdetails) {
		Connection con = null;
		boolean status = false;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/executiveacdb", "root", "");
			Statement ps = con.createStatement();
			Date date = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yy");
		    sdf = new SimpleDateFormat("dd/MM/yyyy");
		    String  strDate = sdf.format(date);
		    System.out.println("formatted date in dd/MM/yyyy : " + strDate);


			ps.executeUpdate("insert into jobresponse(jobrequirementid,postedid,postedname,jobname,details,postdate,responderid,respondername,responderdetails,respondeddate) values('"
					+ jobrequirementid
					+ "','"
					+ postedid
					+ "','"
					+ postedname
					+ "','"
					+ jobname
					+ "','"
					+ details
					+ "','"
					+ postdate
					+ "','"
					+ responderid
					+ "','"
					+ respondername
					+ "','"
					+ responderdetails
					+ "','"
					
					+strDate+"')");
			status = true;
			con.close();
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return status;

	}
	
	public static boolean respondBDRequest(String bloodrequirementid,String postedid,String postedname,String bloodgroup,String details,String postdate,String responderid,String respondername,String responderdetails) {
		Connection con = null;
		boolean status = false;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/executiveacdb", "root", "");
			Statement ps = con.createStatement();
			Date date = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yy");
		    sdf = new SimpleDateFormat("dd/MM/yyyy");
		    String  strDate = sdf.format(date);
		    System.out.println("formatted date in dd/MM/yyyy : " + strDate);


			ps.executeUpdate("insert into bloodresponse(bloodrequirementid,postedid,postedname,bloodgroup,details,postdate,responderid,respondername,responderdetails,respondeddate) values('"
					+ bloodrequirementid
					+ "','"
					+ postedid
					+ "','"
					+ postedname
					+ "','"
					+ bloodgroup
					+ "','"
					+ details
					+ "','"
					+ postdate
					+ "','"
					+ responderid
					+ "','"
					+ respondername
					+ "','"
					+ responderdetails
					+ "','"
					
					+strDate+"')");
			status = true;
			con.close();
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return status;

	}
	
	public static int deleteUser(String userid) {
		Connection con = null;
		// PreparedStatement ps = null;
		ResultSet rs2 = null;
		// boolean status = false;
		/*
		 * String name=changepass.get(0).toString(); String
		 * pass=changepass.get(1).toString(); String
		 * npass=changepass.get(2).toString();
		 */
		int value = 0;

		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/executiveacdb", "root", "");
			Statement ps2 = con.createStatement();

			value = ps2.executeUpdate("update registration set status='deleted' where number='" + userid
					+ "'");

			con.close();
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return value;
	}
	public static int deleteBlog(String userid) {
		Connection con = null;
		// PreparedStatement ps = null;
		ResultSet rs2 = null;
		// boolean status = false;
		/*
		 * String name=changepass.get(0).toString(); String
		 * pass=changepass.get(1).toString(); String
		 * npass=changepass.get(2).toString();
		 */
		int value = 0;

		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/executiveacdb", "root", "");
			Statement ps2 = con.createStatement();

			value = ps2.executeUpdate("update blog set status='deleted' where number='" + userid
					+ "'");

			con.close();
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return value;
	}
	public static int approveUser(String userid) {
		Connection con = null;
		// PreparedStatement ps = null;
		ResultSet rs2 = null;
		// boolean status = false;
		/*
		 * String name=changepass.get(0).toString(); String
		 * pass=changepass.get(1).toString(); String
		 * npass=changepass.get(2).toString();
		 */
		int value = 0;

		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/executiveacdb", "root", "");
			Statement ps2 = con.createStatement();

			value = ps2.executeUpdate("update registration set status='active' where number='" + userid
					+ "'");

			con.close();
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return value;
	}
	public static int approveBlog(String userid) {
		Connection con = null;
		// PreparedStatement ps = null;
		ResultSet rs2 = null;
		// boolean status = false;
		/*
		 * String name=changepass.get(0).toString(); String
		 * pass=changepass.get(1).toString(); String
		 * npass=changepass.get(2).toString();
		 */
		int value = 0;

		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/executiveacdb", "root", "");
			Statement ps2 = con.createStatement();

			value = ps2.executeUpdate("update blog set status='active' where number='" + userid
					+ "'");

			con.close();
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return value;
	}
	
	public static int deleteBdReq(String userid) {
		Connection con = null;
		// PreparedStatement ps = null;
		ResultSet rs2 = null;
		// boolean status = false;
		/*
		 * String name=changepass.get(0).toString(); String
		 * pass=changepass.get(1).toString(); String
		 * npass=changepass.get(2).toString();
		 */
		int value = 0;

		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/executiveacdb", "root", "");
			Statement ps2 = con.createStatement();

			value = ps2.executeUpdate("update bloodrequirements set status='deleted' where number='" + userid
					+ "'");

			con.close();
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return value;
	}
	
	public static int deleteStudentBdReq(String userid) {
		Connection con = null;
		// PreparedStatement ps = null;
		ResultSet rs2 = null;
		// boolean status = false;
		/*
		 * String name=changepass.get(0).toString(); String
		 * pass=changepass.get(1).toString(); String
		 * npass=changepass.get(2).toString();
		 */
		int value = 0;

		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/executiveacdb", "root", "");
			Statement ps2 = con.createStatement();

			value = ps2.executeUpdate("update bloodrequirements set status='deleted' where number='" + userid
					+ "'");

			con.close();
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return value;
	}
	
	public static int deleteFndReq(String fndid) {
		Connection con = null;
		// PreparedStatement ps = null;
		ResultSet rs2 = null;
		// boolean status = false;
		/*
		 * String name=changepass.get(0).toString(); String
		 * pass=changepass.get(1).toString(); String
		 * npass=changepass.get(2).toString();
		 */
		int value = 0;

		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/executiveacdb", "root", "");
			Statement ps2 = con.createStatement();

			value = ps2.executeUpdate("update fundrequirements set status='deleted' where number='" + fndid
					+ "'");

			con.close();
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return value;
	}
	
	public static int deleteJBReq(String userid) {
		Connection con = null;
		// PreparedStatement ps = null;
		ResultSet rs2 = null;
		// boolean status = false;
		/*
		 * String name=changepass.get(0).toString(); String
		 * pass=changepass.get(1).toString(); String
		 * npass=changepass.get(2).toString();
		 */
		int value = 0;

		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/executiveacdb", "root", "");
			Statement ps2 = con.createStatement();

			value = ps2.executeUpdate("update jobrequirements set status='deleted' where number='" + userid
					+ "'");

			con.close();
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return value;
	}
	
	public static int deleteStudentJBReq(String userid) {
		Connection con = null;
		// PreparedStatement ps = null;
		ResultSet rs2 = null;
		// boolean status = false;
		/*
		 * String name=changepass.get(0).toString(); String
		 * pass=changepass.get(1).toString(); String
		 * npass=changepass.get(2).toString();
		 */
		int value = 0;

		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/executiveacdb", "root", "");
			Statement ps2 = con.createStatement();

			value = ps2.executeUpdate("update jobrequirements set status='deleted' where number='" + userid
					+ "'");

			con.close();
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return value;
	}
	
	
	public static boolean postBR(String bloodgroup, String details) {
			Connection con = null;
	boolean status = false;
	try {
		Class.forName("com.mysql.jdbc.Driver");
		con = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/executiveacdb", "root", "");
		Statement ps = con.createStatement();
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yy");
	    sdf = new SimpleDateFormat("dd/MM/yyyy");
	    String  strDate = sdf.format(date);
	    System.out.println("formatted date in dd/MM/yyyy : " + strDate);

String q= "insert into bloodrequirements(postedid,postedname,bloodgroup,details,postdate) values('admin','admin','"
		+ bloodgroup
		+ "','"
		+ details
		+ "','"
		
		+strDate+"')";
System.out.println("Query==="+q);

		ps.executeUpdate(q);
		status = true;
		con.close();
	} catch (SQLException | ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	

	return status;
	}
	
	public static boolean postFR(String fundevent, String fundeventdetails) {
		Connection con = null;
		boolean status = false;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/executiveacdb", "root", "");
			Statement ps = con.createStatement();
			Date date = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yy");
		    sdf = new SimpleDateFormat("dd/MM/yyyy");
		    String  strDate = sdf.format(date);
		    System.out.println("formatted date in dd/MM/yyyy : " + strDate);
		    String q= "insert into fundrequirements(postedid,postedname,fundevent,details,postdate) values('admin','admin','"
			+ fundevent
			+ "','"
			+ fundeventdetails
			+ "','"
			
			+strDate+"')";
			System.out.println("Query==="+q);
		
			ps.executeUpdate(q);
			status = true;
			con.close();
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return status;
	}
	
	public static boolean postJB(String jobname, String details) {
		Connection con = null;
boolean status = false;
try {
	Class.forName("com.mysql.jdbc.Driver");
	con = DriverManager.getConnection(
			"jdbc:mysql://localhost:3306/executiveacdb", "root", "");
	Statement ps = con.createStatement();
	Date date = new Date();
	SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yy");
    sdf = new SimpleDateFormat("dd/MM/yyyy");
    String  strDate = sdf.format(date);
    System.out.println("formatted date in dd/MM/yyyy : " + strDate);

String q= "insert into jobrequirements(postedid,postedname,jobname,jobdetails,postdate) values('admin','admin','"
	+ jobname
	+ "','"
	+ details
	+ "','"
	
	+strDate+"')";
System.out.println("Query==="+q);

	ps.executeUpdate(q);
	status = true;
	con.close();
} catch (SQLException | ClassNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}


return status;
}
	
	public static boolean studentPostJB(String jobname, String details, String studentId, String studentName) {
		Connection con = null;
boolean status = false;
try {
	Class.forName("com.mysql.jdbc.Driver");
	con = DriverManager.getConnection(
			"jdbc:mysql://localhost:3306/executiveacdb", "root", "");
	Statement ps = con.createStatement();
	Date date = new Date();
	SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yy");
    sdf = new SimpleDateFormat("dd/MM/yyyy");
    String  strDate = sdf.format(date);
    System.out.println("formatted date in dd/MM/yyyy : " + strDate);

String q= "insert into jobrequirements(postedid,postedname,jobname,jobdetails,postdate) values('"
		+ studentId
		+ "','"
		+ studentName
		+ "','"
		+ jobname
	+ "','"
	+ details
	+ "','"
	
	+strDate+"')";
System.out.println("Query==="+q);

	ps.executeUpdate(q);
	status = true;
	con.close();
} catch (SQLException | ClassNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}


return status;
}

public static boolean studentPostBD(String bdreq, String bddetails, String studentId, String studentName) {
	Connection con = null;
boolean status = false;
try {
Class.forName("com.mysql.jdbc.Driver");
con = DriverManager.getConnection(
		"jdbc:mysql://localhost:3306/executiveacdb", "root", "");
Statement ps = con.createStatement();
Date date = new Date();
SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yy");
sdf = new SimpleDateFormat("dd/MM/yyyy");
String  strDate = sdf.format(date);
System.out.println("formatted date in dd/MM/yyyy : " + strDate);

String q= "insert into bloodrequirements(postedid,postedname,bloodgroup,details,postdate) values('"
	+ studentId
	+ "','"
	+ studentName
	+ "','"
	+ bdreq
+ "','"
+ bddetails
+ "','"

+strDate+"')";
System.out.println("Query==="+q);

ps.executeUpdate(q);
status = true;
con.close();
} catch (SQLException | ClassNotFoundException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}


return status;
}

	public static int deleteEvent(String eventid) {
		Connection con = null;
		// PreparedStatement ps = null;
		ResultSet rs2 = null;
		// boolean status = false;
		/*
		 * String name=changepass.get(0).toString(); String
		 * pass=changepass.get(1).toString(); String
		 * npass=changepass.get(2).toString();
		 */
		int value = 0;

		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/executiveacdb", "root", "");
			Statement ps2 = con.createStatement();

			value = ps2.executeUpdate("update events set status='deleted' where number='" + eventid
					+ "'");

			con.close();
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return value;
	}
	
	
	public static int deleteStudentsEventResponds(String eventid) {
		Connection con = null;
		// PreparedStatement ps = null;
		ResultSet rs2 = null;
		// boolean status = false;
		/*
		 * String name=changepass.get(0).toString(); String
		 * pass=changepass.get(1).toString(); String
		 * npass=changepass.get(2).toString();
		 */
		int value = 0;

		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/executiveacdb", "root", "");
			Statement ps2 = con.createStatement();

			value = ps2.executeUpdate("update eventresponse set status='deleted' where number='" + eventid
					+ "'");

			con.close();
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return value;
	}
	
	public static int deleteStudentsJobResponds(String eventid) {
		Connection con = null;
		// PreparedStatement ps = null;
		ResultSet rs2 = null;
		// boolean status = false;
		/*
		 * String name=changepass.get(0).toString(); String
		 * pass=changepass.get(1).toString(); String
		 * npass=changepass.get(2).toString();
		 */
		int value = 0;

		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/executiveacdb", "root", "");
			Statement ps2 = con.createStatement();

			value = ps2.executeUpdate("update jobresponse set status='deleted' where number='" + eventid
					+ "'");

			con.close();
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return value;
	}
	
	public static int deleteStudentsBdResponds(String eventid) {
		Connection con = null;
		// PreparedStatement ps = null;
		ResultSet rs2 = null;
		// boolean status = false;
		/*
		 * String name=changepass.get(0).toString(); String
		 * pass=changepass.get(1).toString(); String
		 * npass=changepass.get(2).toString();
		 */
		int value = 0;

		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/executiveacdb", "root", "");
			Statement ps2 = con.createStatement();

			value = ps2.executeUpdate("update bloodresponse set status='deleted' where number='" + eventid
					+ "'");

			con.close();
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return value;
	}
	
	
	
	public static boolean postEvent(String eventName, String eventDetails) {
		Connection con = null;
boolean status = false;
try {
	Class.forName("com.mysql.jdbc.Driver");
	con = DriverManager.getConnection(
			"jdbc:mysql://localhost:3306/executiveacdb", "root", "");
	Statement ps = con.createStatement();
	Date date = new Date();
	SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yy");
    sdf = new SimpleDateFormat("dd/MM/yyyy");
    String  strDate = sdf.format(date);
    System.out.println("formatted date in dd/MM/yyyy : " + strDate);

String q= "insert into events(eventname,eventdetails,date) values('"
	+ eventName
	+ "','"
	+ eventDetails
	+ "','"
	
	+strDate+"')";
System.out.println("Query==="+q);

	ps.executeUpdate(q);
	status = true;
	con.close();
} catch (SQLException | ClassNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}


return status;
}
	
	
	public static int studentUpdate(Student st) {
		Connection con = null;
		int value = 0;

		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/executiveacdb", "root", "");
			Statement ps2 = con.createStatement();
			String query = "update registration set mobilenum='" + st.getMobNumber()
					+ "',emailid='" + st.getEmailId() + "' where number='"
					+ st.getNumber() + "'";
			System.out.println("Qury==" + query);
			value = ps2.executeUpdate(query);

			con.close();
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return value;
	}
	public static boolean postBlog(String uploaderid, String uploaderName,
			String blogname, String blogdetails) {
		Connection con = null;
		boolean status = false;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/executiveacdb", "root", "");
			Statement ps = con.createStatement();
			Date date = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yy");
		    sdf = new SimpleDateFormat("dd/MM/yyyy");
		    String  strDate = sdf.format(date);
		    System.out.println("formatted date in dd/MM/yyyy : " + strDate);

		String q= "insert into blog(uploaderid,uploadername,blogname,blogdetails,blogdate) values('"
			+ uploaderid
			+ "','"
			+ uploaderName
			+ "','"
			+ blogname
			+ "','"
			+ blogdetails
			+ "','"
			
			+strDate+"')";
		System.out.println("Query==="+q);

			ps.executeUpdate(q);
			status = true;
			con.close();
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
	}
		return status;
	}
	
	public static boolean postFB(String uploaderid, String uploaderName,
			String fbname, String fbdetails) {
		Connection con = null;
		boolean status = false;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/executiveacdb", "root", "");
			Statement ps = con.createStatement();
			Date date = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yy");
		    sdf = new SimpleDateFormat("dd/MM/yyyy");
		    String  strDate = sdf.format(date);
		    System.out.println("formatted date in dd/MM/yyyy : " + strDate);

		String q= "insert into feedback(uploaderid,uploadername,fbname,fbdetails,posteddate) values('"
			+ uploaderid
			+ "','"
			+ uploaderName
			+ "','"
			+ fbname
			+ "','"
			+ fbdetails
			+ "','"
			
			+strDate+"')";
		System.out.println("Query==="+q);

			ps.executeUpdate(q);
			status = true;
			con.close();
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
	}
		return status;
	}
	
	public static int videoChat(String fromid,String fromName,String toid,String link) {
		Connection con = null;
		ResultSet rs2 = null;

		int value=0;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/executiveacdb", "root", "");
			Statement ps2 = con.createStatement();
			String p = "approved";
	        Date date = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yy");
		    sdf = new SimpleDateFormat("MM/dd/yyyy");
		    String  strDate = sdf.format(date);
		    System.out.println("formatted date in MM/dd/yyyy : " + strDate);
		    
			String query="insert into videochat(toid,fromid,fromname,link,senddate) values('"+toid+"','"+fromid+"','"+fromName+"','"+link+"','"+strDate+"')";
		    System.out.println(query);
			value=ps2.executeUpdate(query);
			 System.out.println(value);
		Statement ps3 = con.createStatement();
			con.close();
		}catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
	}
		return value;
	}
	
	public static int videoChatu(String chatid) {
		Connection con = null;
		ResultSet rs2 = null;

		int value=0;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/executiveacdb", "root", "");
			Statement ps2 = con.createStatement();
			String p = "closed";
	        Date date = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yy");
		    sdf = new SimpleDateFormat("MM/dd/yyyy");
		    String  strDate = sdf.format(date);
		    System.out.println("formatted date in MM/dd/yyyy : " + strDate);
		    
			String query="update videochat set status='"+p+"',chatdate='"+strDate+"' where id='"+chatid+"'";
		    System.out.println(query);
			value=ps2.executeUpdate(query);
			 System.out.println(value);
		Statement ps3 = con.createStatement();
			con.close();
		}catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
	}
		return value;
	}	
}
