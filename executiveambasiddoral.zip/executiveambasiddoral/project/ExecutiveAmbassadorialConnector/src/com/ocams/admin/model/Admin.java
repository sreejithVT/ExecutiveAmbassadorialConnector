package com.ocams.admin.model;

public class Admin {
	private int number;
	private String firstName;
	private String lastName;
	private String dob;
	private String mobNumber;
	private String emailId;
	private String userName;
	private String passWord;

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getMobNumber() {
		return mobNumber;
	}

	public void setMobNumber(String mobNumber) {
		this.mobNumber = mobNumber;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassWord() {
		return passWord;
	}

	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}

	@Override
	public String toString() {
		return "Admin [number=" + number + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", dob=" + dob + ", mobNumber="
				+ mobNumber + ", emailId=" + emailId + ", userName=" + userName
				+ ", passWord=" + passWord + "]";
	}


}
