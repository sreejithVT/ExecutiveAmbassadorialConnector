package com.ocams.admin.model;

public class Student {
	private int number;
	private String firstName;
	private String lastName;
	private String dob;
	private String mobNumber;
	private String emailId;
	private String registerno;
	//private String anIncome;
	private String collegename;
	private String fingerFile;
	private String course;
	private String cyear;
	private String userid;
	private String password;
	private String imagename;
	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getMobNumber() {
		return mobNumber;
	}

	public void setMobNumber(String mobNumber) {
		this.mobNumber = mobNumber;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	

	
	

	/*public String getAnIncome() {
		return anIncome;
	}

	public void setAnIncome(String anIncome) {
		this.anIncome = anIncome;
	}
*/
	
	
	public String getFingerFile() {
		return fingerFile;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setFingerFile(String fingerFile) {
		this.fingerFile = fingerFile;
	}

	public String getCollegename() {
		return collegename;
	}

	public void setCollegename(String collegename) {
		this.collegename = collegename;
	}

	
	
	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	public String getCyear() {
		return cyear;
	}

	public void setCyear(String cyear) {
		this.cyear = cyear;
	}

	
	public String getRegisterno() {
		return registerno;
	}

	public void setRegisterno(String registerno) {
		this.registerno = registerno;
	}

	
	public String getImagename() {
		return imagename;
	}

	public void setImagename(String imagename) {
		this.imagename = imagename;
	}

	@Override
	public String toString() {
		return "Student [number=" + number + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", dob=" + dob + ", mobNumber="
				+ mobNumber + ", emailId=" + emailId + ", registerno="
				+ registerno + ", collegename=" + collegename + ", fingerFile="
				+ fingerFile + ", course=" + course + ", cyear=" + cyear
				+ ", userid=" + userid + ", password=" + password
				+ ", imagename=" + imagename + "]";
	}

	

	

}
