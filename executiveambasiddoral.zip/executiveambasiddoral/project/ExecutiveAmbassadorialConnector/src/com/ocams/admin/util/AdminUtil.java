package com.ocams.admin.util;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ocams.admin.model.Admin;
import com.ocams.admin.model.Student;


public class AdminUtil {

	
	public static boolean compareAdminValue(Admin user1, Admin user2) {
		// Get the user the detail from data base
		// LoginDAO ldao = new LoginDAO();
		// User userFromDB = ldao.getUserDetails();
		boolean comp = false;
		System.out.println("ok");
		// Comparing the user details
		System.out.println(user1);
		System.out.println(user2);
		System.out.println(user1.getUserName());
		System.out.println(user2.getPassWord());
		if (user1.getUserName().equals(user2.getUserName())) {
			// compare with password
			if (user1.getPassWord().equals(user2.getPassWord())) {
				comp = true;
			}
		} else {

		}

		return comp;
	}
		
	public static boolean compareStudentValue(Student user1, Student user2) {
		// Get the user the detail from data base
		// LoginDAO ldao = new LoginDAO();
		// User userFromDB = ldao.getUserDetails();
		boolean comp = false;
		System.out.println("ok");
		// Comparing the user details
		System.out.println(user1);
		System.out.println(user2);
		if (user1.getUserid().equals(user2.getUserid()) && 
				user1.getPassword().equals(user2.getPassword())) {
			// compare with password
				comp = true;
		} else {

		}

		return comp;
	}

	
	
	public static Student updateStudent(HttpServletRequest request,HttpServletResponse response)
	{
		Student st = new Student();
		int num=-1;
		num = Integer.parseInt(request.getParameter("number"));
		String mobileNum="";
		String email="";
		mobileNum=request.getParameter("mobilenum");
		email=request.getParameter("emailid");
		st.setNumber(num);
		st.setMobNumber(mobileNum);
		st.setEmailId(email);
		System.out.println(st.toString());
		return st;
				
	}
	
	public static ArrayList changePasswordDetails(HttpServletRequest request,HttpServletResponse response)
	{
		ArrayList cpal = new ArrayList();
		String userName="";
		String password="";
		String newPassword="";
		userName=request.getParameter("username");
		password=request.getParameter("password");
		newPassword=request.getParameter("newpassword");
		cpal.add(userName);
		cpal.add(password);
		cpal.add(newPassword);
		
		return cpal;
		
		
	}	

	public static Student populateStudentDetailsFromJsp(HttpServletRequest request,
			HttpServletResponse res) {
		Student detail = new Student();
		if (null != request.getParameter("fname")) {
			detail.setFirstName(request.getParameter("fname"));

		}
		if (null != request.getParameter("lname")) {
			detail.setLastName(request.getParameter("lname"));

		}
		if (null != request.getParameter("dob")) {
			detail.setDob(request.getParameter("dob"));

		}
		if (null != request.getParameter("mobile")) {
			detail.setMobNumber(request.getParameter("mobile"));

		}
		if (null != request.getParameter("email")) {
			detail.setEmailId(request.getParameter("email"));

		}
		if (null != request.getParameter("regno")) {
			detail.setRegisterno(request.getParameter("regno"));

		}
		if (null != request.getParameter("collegename")) {
			detail.setCollegename(request.getParameter("collegename"));

		}
		if (null != request.getParameter("course")) {
			detail.setCourse(request.getParameter("course"));

		}
		if (null != request.getParameter("cyear")) {
			detail.setCyear(request.getParameter("cyear"));

		}
		
		if (null != request.getParameter("userid")) {
			detail.setUserid(request.getParameter("userid"));

		}
		if (null != request.getParameter("pw")) {
			detail.setPassword(request.getParameter("pw"));

		}
		return detail;

	}
	
	public static boolean send(String from, String password, String to,
			String sub, String msg) {
		// Get properties object
		/*boolean status = false;
		Properties props = new Properties();
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.socketFactory.port", "465");
		props.put("mail.smtp.socketFactory.class",
				"javax.net.ssl.SSLSocketFactory");
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.port", "465");
		// get Session
		Session session = Session.getDefaultInstance(props,
				new javax.mail.Authenticator() {
					protected PasswordAuthentication getPasswordAuthentication() {
						return new PasswordAuthentication(from, password);
					}
				});
		// compose message
		try {
			MimeMessage message = new MimeMessage(session);
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(
					to));
			message.setSubject(sub);
			message.setText(msg);
			// send message
			Transport.send(message);
			System.out.println("message sent successfully");
			status = true;
		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}
		return status;*/
		return true;
	}
	public static String getValueFromProperties(String filename, String key) {
		String value = null;
		try {
			// File file = new File("test.properties");
			
			//File file = new File(filename);
			InputStream fileInput = AdminUtil.class.getClassLoader().getResourceAsStream("/"+filename);
			Properties properties = new Properties();
			properties.load(fileInput);
			fileInput.close();

			/*
			 * Enumeration enuKeys = properties.keys(); while
			 * (enuKeys.hasMoreElements()) { String key = (String)
			 * enuKeys.nextElement(); String value =
			 * properties.getProperty(key); System.out.println(key + ": " +
			 * value); }
			 */
			value = properties.getProperty(key).toString();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return value;
	}
}


